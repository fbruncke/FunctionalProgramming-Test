public interface RobotOrderInterface {

    void instructions(String robotName);

}
